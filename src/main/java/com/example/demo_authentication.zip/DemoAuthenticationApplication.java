package com.example.demo_authentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAuthenticationApplication {

  public static void main(String[] args) {
    SpringApplication.run(DemoAuthenticationApplication.class, args);
  }

}
